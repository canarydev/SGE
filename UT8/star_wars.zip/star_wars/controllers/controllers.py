# -*- coding: utf-8 -*-
# from odoo import http


# class StarWars(http.Controller):
#     @http.route('/star_wars/star_wars', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/star_wars/star_wars/objects', auth='public')
#     def list(self, **kw):
#         return http.request.render('star_wars.listing', {
#             'root': '/star_wars/star_wars',
#             'objects': http.request.env['star_wars.star_wars'].search([]),
#         })

#     @http.route('/star_wars/star_wars/objects/<model("star_wars.star_wars"):obj>', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('star_wars.object', {
#             'object': obj
#         })
