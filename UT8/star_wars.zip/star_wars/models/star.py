# -*- coding: utf-8 -*-

from odoo import models, fields

class Star(models.Model):
    _name = 'star_wars.star'
    _description = 'Modelo de estrellas'

    name = fields.Char(string="Nombre",
                       required=True)