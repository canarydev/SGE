# -*- coding: utf-8 -*-

from odoo import models, fields

class System(models.Model):
    _name = 'star_wars.system'
    _description = 'Modelo de sistemas'

    name = fields.Char(string="Nombre",
                       required=True)
    
    star_id = fields.Many2one("star_wars.star", string="Estrella")
    
    planet_ids = fields.One2many(comodel_name="star_wars.planet",
                                 inverse_name='system_id',
                                 string="Planeta/s")