# -*- coding: utf-8 -*-

from odoo import models, fields, api

class Planet(models.Model):
    _name = 'star_wars.planet'
    _description = 'Modelo de planetas'

    name = fields.Char(string="Nombre",
                       required=True)
    diameter = fields.Float(string="Diámetro")
    rotation_period = fields.Float(string="Periodo de rotación")

    orbital_period = fields.Float(string="Periodo orbital")
    gravity = fields.Char(string="Gravedad")
    population = fields.Integer(string="Población")
    climate = fields.Char(string="Clima")
    terrain = fields.Char(string="Terreno")
    surface_water = fields.Float(string="Agua superficial")

    system_id = fields.Many2one(comodel_name="star_wars.system",
                                ondelete='cascade',
                                string="Sistema")

    city_ids = fields.One2many(comodel_name="star_wars.city",
                                 inverse_name='planet_id',
                                 string="Ciudades")
    
    capital_city = fields.Many2one(comodel_name="star_wars.city",
                                   string="Ciudad Capital",
                                   domain="[('planet_id', '=', id)]")


    @api.onchange('diameter')
    def _onchange_diameter(self):
        if self.diameter < 0:
            self.diameter = 0
        elif self.diameter > 100000:
            self.diameter = 100000

    _sql_constraints = [
        ('sw_name_unique', 'UNIQUE(name)', 'No pueden haber dos nombres iguales.')
    ]