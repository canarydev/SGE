# -*- coding: utf-8 -*-

from odoo import models, fields, api

class City(models.Model):
    _name = 'star_wars.city'
    _description = 'Modelo de ciudades'

    name = fields.Char(string="Nombre",
                       required=True)
    
    planet_id = fields.Many2one(comodel_name="star_wars.planet",
                                ondelete='cascade',
                                string="Planeta")